<div class="col-sm-3 col-md-3 col-lg-3 clearfix top-off">
  <div class="row">
    <div class="list-group" id="list-tab" role="tablist" style="width: 100%;">
      <a class="list-group-item list-group-item-action" id="list-home-list" data-toggle="list" href="member" role="tab" aria-controls="home"><i class="fa fa-dashboard"></i> Beranda Sedekah</a>
      <a class="list-group-item list-group-item-action" id="list-home-list" data-toggle="list" href="galangdana" role="tab" aria-controls="galangdana"><i class="fa fa-briefcase"></i> Galang Dana</a>
      <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="donasisaya" role="tab" aria-controls="messages"><i class="fa fa-heart"></i> Sedekah Saya</a>
      <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="profile" role="tab" aria-controls="profile"><i class="fa fa-user"></i> Profile</a>
	  <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="ubahsandi" role="tab" aria-controls="messages"><i class="fa fa-gear"></i> Ubah Kata Sandi</a>   
	  <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="logout" role="tab" aria-controls="messages"><i class="fa fa-sign-out"></i> Keluar</a>      
    </div>
  </div>
</div>