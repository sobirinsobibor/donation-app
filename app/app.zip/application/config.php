<?php

define('BASEURL', 'http://localhost/donation-app/app');

define('DBNAME', 'donate_it_now');
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBPASS', '');

?>