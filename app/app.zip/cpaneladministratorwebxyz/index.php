<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=pages/index.php?page=home">
<title>Master Admin Sedenasto</title>
<script language="javascript">
    window.location.href = "pages/index.php?page=home"
</script>
</head>
<body>
Go to <a href="pages/index.php?page=home">/pages/index.php?page=home</a>
</body>
</html>
